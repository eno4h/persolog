<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * Thee attributes that should be hidden for arrays.
     *
     * @var arrayasd
     */
    protected $hidden = [
        'password', 'remember_token',
    ];
}
