<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use Symfony\Component\HttpFoundation\Response;

class BlogController extends Controller
{
    //homepage

    public function blog_index(Response $response){
        return view('cms.index');
    }
    
    public function posts(Response $response){
        return view('cms.post');
    }

    public function about(Response $response){
        return view('cms.about');
    }

    public function contact(Response $response){
        return view('cms.contact');
    }
}
